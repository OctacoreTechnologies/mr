 <div class="dropdown-menu dropdown-menu-right shadow">
                    <a class="dropdown-item" href="{{route('material-to-process.index')}}"><i class="fas fa-cogs mr-2"></i> Material To Process</a>
                    <a class="dropdown-item" href="{{route('batch.index')}}"><i class="fas fa-boxes mr-2"></i> Batch</a>
                    <a class="dropdown-item" href="{{route('mixing-tool.index')}}"><i class="fas fa-tools mr-2"></i> Mixing Tool</a>
                    <a class="dropdown-item" href="{{route('motor-requirement.index')}}"><i class="fas fa-bolt mr-2"></i> Motor Requirement</a>
                    <a class="dropdown-item" href="{{ route('make-motor.index') }}"><i class="fas fa-industry mr-2"></i> Motor Make</a> 
                    <a class="dropdown-item" href="{{route('electrical-control.index')}}"><i class="fas fa-microchip mr-2"></i> Electrical Control</a>
                    <a class="dropdown-item" href="{{route('ac-frequency-drive.index')}}"><i class="fas fa-sliders-h mr-2"></i> AC Frequency Drive</a>
                    <a class="dropdown-item" href="{{route('bearing.index')}}"><i class="fas fa-circle-notch mr-2"></i> Bearing</a>
                    <a class="dropdown-item" href="{{route('pneumatic.index')}}"><i class="fas fa-wind mr-2"></i> Pneumatics</a>
                    <a class="dropdown-item" href="{{route('model.index')}}"><i class="fas fa-circle mr-2"></i> Model</a>
                    <a class="dropdown-item" href="{{route('capacity.index')}}"><i class="fas fa-tachometer-alt mr-2"></i> Capacity</a>
                    <a class="dropdown-item" href="{{route('blade.index')}}"><i class="fas fa-cut mr-2"></i> Blade</a>
                </div>