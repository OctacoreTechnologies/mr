<!-- resources/views/emails/dynamic_plain_html.blade.php -->
<!doctype html>
<html>
<head><meta charset="utf-8"></head>
<body>
{!! $html !!}
</body>
</html>
