<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class added_column_in_quotations_table extends Controller
{
    //
}
